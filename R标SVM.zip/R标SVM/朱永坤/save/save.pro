TEMPLATE = app
CONFIG += console c++11
CONFIG -= app_bundle
CONFIG -= qt

INCLUDEPATH += /usr/local/include /
               /usr/local/include/opencv
               /usr/local/include/opencv2
LIBS += /usr/local/lib/*.so.*

LIBS +=-lpthread

SOURCES += \
        main.cpp \
        save.cpp

HEADERS += \
    save.h
