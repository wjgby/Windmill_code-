#include<opencv2/opencv.hpp>
#include<iostream>

using namespace std;
using namespace cv;


int main()
{
    VideoCapture cap("/home/newmaker11/下载/Video_20250214203854774.mp4");//导入视频
    Mat result;
    Mat R;
    int min=200;
    namedWindow("Control", WINDOW_AUTOSIZE);
    createTrackbar("min", "Control", &min, 255);
//------------------------------------------------------------------------------
    char ad[128] = { 0 };
    int i =0;
//-------------------------------------------------------------------------------
    Mat image;


    while (1) {
        double start_time; start_time = getCPUTickCount();
    //    image = camera.GetFrame();
        cap >> image;
        if (image.empty()) {
            std::cerr << "Error: Image is empty!" << std::endl;
            return -1;
        }
        cvtColor(image,result,COLOR_BGR2GRAY);//以下为作二值化处理
        threshold(~result,result,min,255,THRESH_BINARY_INV /*| THRESH_OTSU*/);
        Mat struct1 = getStructuringElement(1, Size(3, 3));
        dilate(result, result, struct1, Point(-1, -1), 8);


        RotatedRect light_ellipse;
        vector<vector<Point>> lightContours;
        Mat contourImg;
        result.copyTo(contourImg);
        findContours(contourImg,lightContours,RETR_EXTERNAL,CHAIN_APPROX_SIMPLE);//找到轮廓,耗时

        for (uint i = 0;i < lightContours.size();i++)
        {
            if(lightContours[i].size()<6)continue;

            //椭
            light_ellipse = fitEllipse(lightContours[i]);
            if(light_ellipse.size.area() < 300)continue;
            cout << i << "   " << light_ellipse.size.area() << endl;
//            ellipse(image,light_ellipse,Scalar(50,250,50),2,8);

        }
        Point2f Vertices[4];
        Vertices[0] = Point2f(light_ellipse.center.x-1.5*light_ellipse.size.width, light_ellipse.center.y-1.5*light_ellipse.size.height);
        Vertices[1] = Point2f(light_ellipse.center.x+1.5*light_ellipse.size.width, light_ellipse.center.y-1.5*light_ellipse.size.height);
        Vertices[2] = Point2f(light_ellipse.center.x+1.5*light_ellipse.size.width, light_ellipse.center.y+1.5*light_ellipse.size.height);
        Vertices[3] = Point2f(light_ellipse.center.x-1.5*light_ellipse.size.width, light_ellipse.center.y+1.5*light_ellipse.size.height);
        Mat rotation;
        Point2f dst_points[4];
        dst_points[0] = Point2f(0.0,    0.0  );
        dst_points[1] = Point2f(50.0,   0.0  );
        dst_points[2] = Point2f(50.0,   50.0 );
        dst_points[3] = Point2f(0.0,    50.0 );
        rotation = getPerspectiveTransform(Vertices,dst_points);//透视方式（最好写透视变换矩阵，才不显的low）
        warpPerspective(result,R,rotation,Size(50,50));


//--------------------------------训练模型获取样本用-----------------------------------------
//    resize(image,image,Size(20,20));

        sprintf(ad, "/home/newmaker11/gby总/能量机关分文件(made by GG_Bond)/predict_C++/R_photoes/%d.jpg",i);
        imwrite(ad,R);
        i++;
//--------------------------------------------------------------------------
            imshow("R",R);
            imshow("image",image);
            imshow("result",result);
            if(waitKey(10)==' ')//设置合适
                break;
        }
    return 0;
}
